# TRASH+UAVVaste > uavvaste-base
https://universe.roboflow.com/trash-northeastern/trash-uavvaste

Provided by a Roboflow user
License: CC BY 4.0

